
const Product = require('../models/product');

const createProduct = async (req, res) => {
};

const getAllProducts = async (req, res) => {
};

const getProductById = async (req, res) => {
};

const updateProduct = async (req, res) => {
};

const deleteProduct = async (req, res) => {
};

module.exports = {
  createProduct,
  getAllProducts,
  getProductById,
  updateProduct,
  deleteProduct,
};
