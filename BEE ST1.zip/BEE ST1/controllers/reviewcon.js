
const Review = require('../models/review');

const addReview = async (req, res) => {
 
};

const getAllReviews = async (req, res) => {
  
};

const updateReview = async (req, res) => {
 
};

const deleteReview = async (req, res) => {
  
};

module.exports = {
  addReview,
  getAllReviews,
  updateReview,
  deleteReview,
};
